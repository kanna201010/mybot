// Dashboard API server
module.exports = () => {/* WebSocket + REST */};