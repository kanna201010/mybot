// Telegram bot handler
module.exports = () => {/* commands */};