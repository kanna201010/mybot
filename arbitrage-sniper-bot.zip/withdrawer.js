// Withdraw profits
module.exports = () => {/* withdraw logic */};