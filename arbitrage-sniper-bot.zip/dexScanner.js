// Scan all DEXs for prices
module.exports = () => {/* scan logic */};