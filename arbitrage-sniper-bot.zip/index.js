// Entry point
console.log('Bot started');