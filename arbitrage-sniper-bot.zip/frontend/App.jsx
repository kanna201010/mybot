// React app entry
export default function App() { return <div>Dashboard</div>; }