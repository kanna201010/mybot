// Detect new token launches
module.exports = () => {/* listen to PairCreated */};