// 1s loop
module.exports = () => { setInterval(() => {/* trade */}, 1000); };